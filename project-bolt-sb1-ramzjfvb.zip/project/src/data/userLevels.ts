import { UserLevel } from '../types';

export const userLevels: UserLevel[] = [
  {
    id: 'beginner',
    name: 'Débutant',
    description: 'Je découvre tout juste l\'IA',
    icon: 'Seedling',
    vocabulary: 'simple'
  },
  {
    id: 'intermediate', 
    name: 'Intermédiaire',
    description: 'J\'ai déjà testé quelques outils IA',
    icon: 'Rocket',
    vocabulary: 'intermediate'
  },
  {
    id: 'advanced',
    name: 'Avancé',
    description: 'Je suis à l\'aise avec la technologie',
    icon: 'Zap',
    vocabulary: 'advanced'
  }
];