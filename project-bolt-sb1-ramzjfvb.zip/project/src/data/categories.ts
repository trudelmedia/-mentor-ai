import { Category } from '../types';

export const categories: Category[] = [
  {
    id: 'education',
    name: 'Éducation',
    description: 'Apprendre, enseigner, réviser',
    icon: 'GraduationCap',
    prompt: 'Tu es un pédagogue bienveillant qui aide à créer des méthodes d\'apprentissage personnalisées et efficaces.',
    examples: [
      'Créer un plan de révision pour mes examens',
      'Expliquer les fractions à mon enfant de 8 ans',
      'Apprendre l\'espagnol en 3 mois'
    ]
  },
  {
    id: 'family',
    name: 'Famille',
    description: 'Organisation familiale, activités',
    icon: 'Users',
    prompt: 'Tu es un conseiller familial qui propose des solutions pratiques pour harmoniser la vie de famille.',
    examples: [
      'Organiser les tâches ménagères en famille',
      'Créer des activités pour un anniversaire d\'enfant',
      'Gérer les disputes entre frères et sœurs'
    ]  
  },
  {
    id: 'work',
    name: 'Travail',
    description: 'Productivité, organisation pro',
    icon: 'Briefcase',
    prompt: 'Tu es un coach professionnel qui optimise la productivité et l\'organisation au travail.',
    examples: [
      'Optimiser ma gestion des emails',
      'Préparer une présentation percutante',
      'Organiser mon planning de la semaine'
    ]
  },
  {
    id: 'emotional',
    name: 'Émotionnel',
    description: 'Stress, motivation, bien-être',
    icon: 'Heart',
    prompt: 'Tu es un accompagnateur empathique qui aide à gérer les émotions et le stress du quotidien.',
    examples: [
      'Gérer mon stress avant un entretien',
      'Retrouver la motivation après un échec',
      'Améliorer ma confiance en moi'
    ]
  },
  {
    id: 'time',
    name: 'Gestion du temps',
    description: 'Planning, organisation, priorités',
    icon: 'Clock',
    prompt: 'Tu es un expert en gestion du temps qui aide à organiser et prioriser efficacement.',
    examples: [
      'Créer un planning équilibré travail-vie perso',
      'Éliminer les distractions et procrastination',
      'Organiser ma journée pour être plus productif'
    ]
  },
  {
    id: 'creation',
    name: 'Création',
    description: 'Art, écriture, projets créatifs',
    icon: 'Palette',
    prompt: 'Tu es un mentor créatif qui stimule l\'imagination et guide les projets artistiques.',
    examples: [
      'Écrire une histoire courte originale',
      'Créer un logo pour mon projet',
      'Trouver des idées de décoration pour ma maison'
    ]
  },
  {
    id: 'automation',
    name: 'Automatisation',
    description: 'Simplifier les tâches répétitives',
    icon: 'Zap',
    prompt: 'Tu es un expert en automatisation qui aide à simplifier et optimiser les tâches répétitives.',
    examples: [
      'Automatiser ma gestion de photos',
      'Créer des modèles d\'emails récurrents',
      'Organiser automatiquement mes fichiers'
    ]
  },
  {
    id: 'health',
    name: 'Santé/Bien-être',
    description: 'Forme, nutrition, habitudes',
    icon: 'Activity',
    prompt: 'Tu es un conseiller en bien-être qui propose des approches saines et équilibrées.',
    examples: [
      'Créer un programme d\'exercices adapté',
      'Planifier des repas équilibrés',
      'Développer de meilleures habitudes de sommeil'
    ]
  },
  {
    id: 'finance',
    name: 'Finance',
    description: 'Budget, économies, investissements',
    icon: 'DollarSign',
    prompt: 'Tu es un conseiller financier qui aide à gérer le budget et planifier l\'avenir financier.',
    examples: [
      'Créer un budget familial réaliste',
      'Économiser pour un projet important',
      'Comprendre les bases de l\'investissement'
    ]
  },
  {
    id: 'leisure',
    name: 'Loisirs',
    description: 'Hobbies, voyages, divertissement',
    icon: 'GameController2',
    prompt: 'Tu es un guide de loisirs qui aide à découvrir et planifier des activités enrichissantes.',
    examples: [
      'Planifier un week-end parfait en famille',
      'Découvrir de nouveaux hobbies adaptés',
      'Organiser un voyage avec un budget limité'
    ]
  }
];