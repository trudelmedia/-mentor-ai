import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Sparkles, Search, Zap } from 'lucide-react';
import { useAppContext } from '../contexts/AppContext';
import { StepProps } from '../types';
import { analyzeUserProblem, retryWithBackoff } from '../utils/openai';
import Navigation from '../components/Navigation';
import toast from 'react-hot-toast';

const Step4Analysis: React.FC<StepProps> = ({ onNext, onPrevious }) => {
  const { 
    selectedCategory, 
    problemDescription, 
    userLevel, 
    uploadedFiles,
    setAiResponse,
    setIsLoading,
    setError,
    isLoading,
    error,
    aiResponse
  } = useAppContext();

  const [analysisStep, setAnalysisStep] = useState(0);
  const [hasStartedAnalysis, setHasStartedAnalysis] = useState(false);

  const analysisSteps = [
    { icon: Search, label: 'Analyse du contexte', description: 'Compréhension de votre situation' },
    { icon: Brain, label: 'Recherche de solutions', description: 'Identification des outils IA adaptés' },
    { icon: Sparkles, label: 'Génération de recommandations', description: 'Création de votre plan personnalisé' }
  ];

  const runAnalysis = async () => {
    if (!selectedCategory || !userLevel || hasStartedAnalysis) return;

    setHasStartedAnalysis(true);
    setIsLoading(true);
    setError(null);

    try {
      // Simulate analysis steps
      for (let i = 0; i < analysisSteps.length; i++) {
        setAnalysisStep(i);
        await new Promise(resolve => setTimeout(resolve, 1500));
      }

      // Call OpenAI API with retry logic
      const response = await retryWithBackoff(async () => {
        return await analyzeUserProblem(
          selectedCategory,
          problemDescription,
          userLevel,
          uploadedFiles
        );
      });

      setAiResponse(response);
      toast.success('Analyse terminée avec succès !');
      
      // Auto-proceed to next step after a short delay
      setTimeout(() => {
        onNext();
      }, 2000);

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Une erreur inattendue s\'est produite';
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    // Start analysis when component mounts if we have all required data
    if (selectedCategory && userLevel && problemDescription.length >= 50) {
      runAnalysis();
    }
  }, []);

  const retryAnalysis = () => {
    setHasStartedAnalysis(false);
    setAnalysisStep(0);
    setError(null);
    runAnalysis();
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-12">
          <motion.div
            animate={{ rotate: isLoading ? 360 : 0 }}
            transition={{ duration: 2, repeat: isLoading ? Infinity : 0, ease: 'linear' }}
            className="inline-block"
          >
            <Brain className="w-16 h-16 text-blue-500 mx-auto mb-4" />
          </motion.div>
          
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            {isLoading ? 'Analyse en cours...' : aiResponse ? 'Analyse terminée !' : error ? 'Erreur d\'analyse' : 'Prêt pour l\'analyse'}
          </h1>
          
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            {isLoading 
              ? 'Notre IA analyse votre situation et recherche les meilleures solutions pour vous.'
              : aiResponse 
                ? 'Votre analyse personnalisée est prête ! Passons aux résultats.'
                : error
                  ? 'Une erreur s\'est produite lors de l\'analyse. Vous pouvez réessayer.'
                  : 'Nous allons analyser votre situation avec l\'IA pour vous proposer les meilleures solutions.'
            }
          </p>
        </div>

        <AnimatePresence mode="wait">
          {isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              {analysisSteps.map((step, index) => {
                const IconComponent = step.icon;
                const isActive = analysisStep >= index;
                const isCurrent = analysisStep === index;

                return (
                  <motion.div
                    key={index}
                    className={`
                      flex items-center p-6 rounded-xl border-2 transition-all duration-500
                      ${isActive 
                        ? 'border-blue-500 bg-blue-50' 
                        : 'border-gray-200 bg-gray-50'
                      }
                    `}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.2 }}
                  >
                    <div className={`
                      w-12 h-12 rounded-full flex items-center justify-center mr-4
                      ${isActive 
                        ? 'bg-blue-500 text-white' 
                        : 'bg-gray-300 text-gray-500'
                      }
                    `}>
                      {isCurrent && isLoading ? (
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                        >
                          <IconComponent className="w-6 h-6" />
                        </motion.div>
                      ) : (
                        <IconComponent className="w-6 h-6" />
                      )}
                    </div>
                    
                    <div className="flex-1">
                      <h3 className={`
                        font-semibold text-lg
                        ${isActive ? 'text-blue-900' : 'text-gray-700'}
                      `}>
                        {step.label}
                      </h3>
                      <p className={`
                        ${isActive ? 'text-blue-700' : 'text-gray-500'}
                      `}>
                        {step.description}
                      </p>
                    </div>

                    {isActive && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="ml-4"
                      >
                        <Zap className="w-6 h-6 text-green-500" />
                      </motion.div>
                    )}
                  </motion.div>
                );
              })}

              <div className="mt-8 p-6 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl text-white text-center">
                <motion.div
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <Sparkles className="w-8 h-8 mx-auto mb-2" />
                  <p className="font-medium">
                    Génération de votre plan personnalisé en cours...
                  </p>
                </motion.div>
              </div>
            </motion.div>
          )}

          {error && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center space-y-6"
            >
              <div className="bg-red-50 border-2 border-red-200 rounded-xl p-8">
                <div className="text-red-500 mb-4">
                  <svg className="w-16 h-16 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-red-900 mb-2">
                  Oups ! Une erreur s'est produite
                </h3>
                <p className="text-red-700 mb-4">{error}</p>
                <button
                  onClick={retryAnalysis}
                  className="bg-red-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-600 transition-colors"
                >
                  Réessayer l'analyse
                </button>
              </div>
            </motion.div>
          )}

          {aiResponse && !isLoading && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-green-50 border-2 border-green-200 rounded-xl p-8 text-center"
            >
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 0.5 }}
              >
                <Sparkles className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-green-900 mb-2">
                  Analyse terminée avec succès !
                </h3>
                <p className="text-green-700 mb-4">
                  Votre plan personnalisé est prêt. Découvrez nos recommandations dans l'étape suivante.
                </p>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <Navigation
          onPrevious={onPrevious}
          onNext={onNext}
          canGoBack={!isLoading}
          canProceed={!!aiResponse && !isLoading}
          isLoading={isLoading}
          nextLabel="Voir les résultats"
        />
      </motion.div>
    </div>
  );
};

export default Step4Analysis;