import React from 'react';
import { motion } from 'framer-motion';
import * as LucideIcons from 'lucide-react';
import { useAppContext } from '../contexts/AppContext';
import { categories } from '../data/categories';
import { StepProps } from '../types';
import Navigation from '../components/Navigation';

const Step1Category: React.FC<StepProps> = ({ onNext, onPrevious, canProceed }) => {
  const { selectedCategory, setSelectedCategory } = useAppContext();

  const handleCategorySelect = (category: typeof categories[0]) => {
    setSelectedCategory(category);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Dans quel domaine l'IA peut-elle vous aider ?
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Choisissez la catégorie qui correspond le mieux à votre situation. 
            Nous personnaliserons nos recommandations en fonction de votre choix.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {categories.map((category, index) => {
            const IconComponent = (LucideIcons as any)[category.icon] || LucideIcons.HelpCircle;
            const isSelected = selectedCategory?.id === category.id;

            return (
              <motion.button
                key={category.id}
                onClick={() => handleCategorySelect(category)}
                className={`
                  p-6 rounded-xl text-left transition-all duration-200 border-2
                  ${isSelected
                    ? 'border-blue-500 bg-blue-50 shadow-lg'
                    : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-md'
                  }
                `}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className={`
                  w-12 h-12 rounded-lg flex items-center justify-center mb-4
                  ${isSelected ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-600'}
                `}>
                  <IconComponent className="w-6 h-6" />
                </div>
                
                <h3 className={`
                  font-semibold text-lg mb-2
                  ${isSelected ? 'text-blue-900' : 'text-gray-900'}
                `}>
                  {category.name}
                </h3>
                
                <p className={`
                  text-sm leading-relaxed
                  ${isSelected ? 'text-blue-700' : 'text-gray-600'}
                `}>
                  {category.description}
                </p>

                {isSelected && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="mt-4 pt-4 border-t border-blue-200"
                  >
                    <p className="text-xs text-blue-600 font-medium">
                      Exemples : {category.examples[0]}
                    </p>
                  </motion.div>
                )}
              </motion.button>
            );
          })}
        </div>

        {selectedCategory && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 p-6 bg-green-50 rounded-lg border border-green-200"
          >
            <h4 className="font-semibold text-green-900 mb-2">
              Parfait ! Vous avez choisi : {selectedCategory.name}
            </h4>
            <p className="text-green-700">
              Nous allons personnaliser nos recommandations pour vous aider avec {selectedCategory.description.toLowerCase()}.
            </p>
          </motion.div>
        )}

        <Navigation
          onPrevious={onPrevious}
          onNext={onNext}
          canGoBack={false}
          canProceed={canProceed}
        />
      </motion.div>
    </div>
  );
};

export default Step1Category;