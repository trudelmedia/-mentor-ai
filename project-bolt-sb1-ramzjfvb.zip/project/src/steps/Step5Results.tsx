import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Download, 
  Share2, 
  Star, 
  CheckCircle, 
  ExternalLink, 
  Mail,
  RotateCcw,
  Heart
} from 'lucide-react';
import { useAppContext } from '../contexts/AppContext';
import { StepProps } from '../types';
import Navigation from '../components/Navigation';
import toast from 'react-hot-toast';

const Step5Results: React.FC<StepProps> = ({ onPrevious }) => {
  const { 
    aiResponse, 
    selectedCategory, 
    userLevel,
    rating,
    setRating,
    feedback,
    setFeedback,
    resetState
  } = useAppContext();

  const [showEmailForm, setShowEmailForm] = useState(false);
  const [email, setEmail] = useState('');
  const [hasRated, setHasRated] = useState(false);

  const handleRating = (newRating: number) => {
    setRating(newRating);
    setHasRated(true);
    toast.success('Merci pour votre évaluation !');
  };

  const handleDownloadPDF = () => {
    // In a real app, you'd use jsPDF or similar
    toast.success('Téléchargement du PDF en cours...');
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Mes recommandations IA personnalisées',
          text: 'Découvrez comment l\'IA peut vous aider dans votre quotidien !',
          url: window.location.href
        });
      } catch (error) {
        // Fallback to copy link
        copyLink();
      }
    } else {
      copyLink();
    }
  };

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success('Lien copié dans le presse-papiers !');
  };

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      toast.success('Recommandations envoyées par email !');
      setShowEmailForm(false);
      setEmail('');
    }
  };

  const handleStartOver = () => {
    resetState();
    toast.success('Nouvelle session démarrée !');
  };

  // Parse AI response sections (simplified)
  const parseResponse = (response: string) => {
    const sections = response.split(/(?=\d+\.\s|\*\*)/g).filter(s => s.trim());
    return {
      analysis: sections.find(s => s.toLowerCase().includes('analyse')) || '',
      solutions: sections.find(s => s.toLowerCase().includes('solution')) || '',
      tools: sections.find(s => s.toLowerCase().includes('outil')) || '',
      example: sections.find(s => s.toLowerCase().includes('exemple')) || '',
      nextSteps: sections.find(s => s.toLowerCase().includes('étape')) || ''
    };
  };

  const sections = parseResponse(aiResponse);

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center mb-12">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring' }}
          >
            <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-6" />
          </motion.div>
          
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Vos recommandations personnalisées !
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-6">
            Voici comment l'IA peut transformer votre approche du {selectedCategory?.name.toLowerCase()}. 
            Ces solutions sont adaptées à votre niveau {userLevel?.name.toLowerCase()}.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <motion.button
              onClick={handleDownloadPDF}
              className="flex items-center px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Download className="w-5 h-5 mr-2" />
              Télécharger PDF
            </motion.button>
            
            <motion.button
              onClick={handleShare}
              className="flex items-center px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Share2 className="w-5 h-5 mr-2" />
              Partager
            </motion.button>
            
            <motion.button
              onClick={() => setShowEmailForm(true)}
              className="flex items-center px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Mail className="w-5 h-5 mr-2" />
              Recevoir par email
            </motion.button>
          </div>
        </div>

        {/* Email Form Modal */}
        {showEmailForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="bg-white rounded-xl p-6 w-full max-w-md"
            >
              <h3 className="text-xl font-bold mb-4">Recevoir par email</h3>
              <form onSubmit={handleEmailSubmit}>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="votre@email.com"
                  className="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
                  required
                />
                <div className="flex gap-3">
                  <button
                    type="submit"
                    className="flex-1 bg-blue-500 text-white py-3 rounded-lg hover:bg-blue-600 transition-colors"
                  >
                    Envoyer
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowEmailForm(false)}
                    className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Annuler
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}

        {/* Results Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white rounded-xl shadow-lg p-8 border border-gray-200"
            >
              <div className="prose prose-lg max-w-none">
                <div className="whitespace-pre-wrap leading-relaxed text-gray-800">
                  {aiResponse}
                </div>
              </div>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Rating */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-white rounded-xl shadow-lg p-6 border border-gray-200"
            >
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <Heart className="w-5 h-5 mr-2 text-red-500" />
                Évaluez cette expérience
              </h3>
              
              <div className="flex gap-2 mb-4">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => handleRating(star)}
                    className={`
                      w-8 h-8 transition-colors
                      ${rating >= star ? 'text-yellow-400' : 'text-gray-300 hover:text-yellow-300'}
                    `}
                  >
                    <Star className="w-full h-full fill-current" />
                  </button>
                ))}
              </div>

              {hasRated && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                >
                  <textarea
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    placeholder="Partagez votre avis (optionnel)..."
                    className="w-full p-3 border border-gray-300 rounded-lg resize-none"
                    rows={3}
                  />
                </motion.div>
              )}
            </motion.div>

            {/* Summary */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
              className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl p-6 border border-blue-200"
            >
              <h3 className="text-lg font-semibold mb-4 text-blue-900">
                Résumé de votre parcours
              </h3>
              
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Catégorie :</span>
                  <span className="font-medium text-blue-800">{selectedCategory?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Niveau :</span>
                  <span className="font-medium text-blue-800">{userLevel?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Fichiers :</span>
                  <span className="font-medium text-blue-800">
                    {/* {uploadedFiles.length} fichier(s) */}
                    Aucun fichier
                  </span>
                </div>
              </div>
            </motion.div>

            {/* Call to Actions */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
              className="bg-white rounded-xl shadow-lg p-6 border border-gray-200"
            >
              <h3 className="text-lg font-semibold mb-4">Prochaines étapes</h3>
              
              <div className="space-y-3">
                <button className="w-full flex items-center justify-center px-4 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Explorer plus d'outils IA
                </button>
                
                <button 
                  onClick={handleStartOver}
                  className="w-full flex items-center justify-center px-4 py-3 border-2 border-gray-300 text-gray-700 rounded-lg hover:border-gray-400 hover:bg-gray-50 transition-all"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Nouvelle consultation
                </button>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Navigation */}
        <Navigation
          onPrevious={onPrevious}
          onNext={() => {}}
          canGoBack={true}
          canProceed={false}
        />
      </motion.div>
    </div>
  );
};

export default Step5Results;