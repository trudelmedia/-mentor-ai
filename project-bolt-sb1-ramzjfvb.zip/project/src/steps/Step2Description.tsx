import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Lightbulb, Upload } from 'lucide-react';
import { useAppContext } from '../contexts/AppContext';
import { StepProps } from '../types';
import Navigation from '../components/Navigation';
import FileUpload from '../components/FileUpload';

const Step2Description: React.FC<StepProps> = ({ onNext, onPrevious, canProceed }) => {
  const { problemDescription, setProblemDescription, selectedCategory } = useAppContext();
  const [showExamples, setShowExamples] = useState(false);
  const [currentExampleIndex, setCurrentExampleIndex] = useState(0);

  const examples = selectedCategory?.examples || [
    'Je veux automatiser ma gestion d\'emails quotidienne',
    'Comment créer du contenu engageant pour mon blog ?',
    'J\'ai besoin d\'aide pour organiser mon planning famille'
  ];

  // Rotate examples every 3 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentExampleIndex((prev) => (prev + 1) % examples.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [examples.length]);

  const handleDescriptionChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setProblemDescription(e.target.value);
  };

  const insertExample = (example: string) => {
    setProblemDescription(example);
    setShowExamples(false);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Décrivez votre situation
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Expliquez-nous votre problème ou objectif comme si vous parliez à un ami. 
            Plus vous serez précis, meilleures seront nos recommandations.
          </p>
        </div>

        <div className="space-y-8">
          <div>
            <label htmlFor="description" className="block text-lg font-semibold text-gray-900 mb-4">
              Votre situation :
            </label>
            
            <motion.div
              className="relative"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <textarea
                id="description"
                value={problemDescription}
                onChange={handleDescriptionChange}
                placeholder={`Exemple : ${examples[currentExampleIndex]}`}
                className="w-full min-h-[200px] p-6 border-2 border-gray-300 rounded-xl resize-none
                         focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 transition-all
                         text-lg leading-relaxed"
                maxLength={2000}
              />
              
              <div className="absolute bottom-4 right-4 text-sm text-gray-500">
                {problemDescription.length}/2000
              </div>
            </motion.div>

            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => setShowExamples(!showExamples)}
                  className="flex items-center px-4 py-2 text-blue-600 hover:text-blue-700 
                           hover:bg-blue-50 rounded-lg transition-colors"
                >
                  <Lightbulb className="w-4 h-4 mr-2" />
                  Besoin d'inspiration ?
                </button>
                
                <div className={`
                  px-3 py-1 rounded-full text-sm font-medium
                  ${problemDescription.length >= 50 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-yellow-100 text-yellow-800'
                  }
                `}>
                  {problemDescription.length >= 50 ? '✓ Assez détaillé' : `${50 - problemDescription.length} caractères minimum`}
                </div>
              </div>
            </div>
          </div>

          {showExamples && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-blue-50 rounded-lg p-6 border border-blue-200"
            >
              <h4 className="font-semibold text-blue-900 mb-4">Exemples pour vous inspirer :</h4>
              <div className="grid gap-3">
                {examples.map((example, index) => (
                  <button
                    key={index}
                    onClick={() => insertExample(example)}
                    className="text-left p-3 bg-white rounded-lg border border-blue-200 
                             hover:border-blue-300 hover:shadow-sm transition-all"
                  >
                    <p className="text-blue-800">{example}</p>
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          <div className="border-t border-gray-200 pt-8">
            <div className="flex items-center mb-4">
              <Upload className="w-5 h-5 text-gray-600 mr-2" />
              <h3 className="text-lg font-semibold text-gray-900">
                Documents complémentaires (optionnel)
              </h3>
            </div>
            <p className="text-gray-600 mb-6">
              Ajoutez des fichiers pour nous aider à mieux comprendre votre contexte : 
              captures d'écran, documents, exemples...
            </p>
            <FileUpload />
          </div>
        </div>

        <Navigation
          onPrevious={onPrevious}
          onNext={onNext}
          canGoBack={true}
          canProceed={canProceed}
        />
      </motion.div>
    </div>
  );
};

export default Step2Description;