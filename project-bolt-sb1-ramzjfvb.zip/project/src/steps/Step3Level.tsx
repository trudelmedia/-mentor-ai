import React from 'react';
import { motion } from 'framer-motion';
import * as LucideIcons from 'lucide-react';
import { useAppContext } from '../contexts/AppContext';
import { userLevels } from '../data/userLevels';
import { StepProps } from '../types';
import Navigation from '../components/Navigation';

const Step3Level: React.FC<StepProps> = ({ onNext, onPrevious, canProceed }) => {
  const { userLevel, setUserLevel } = useAppContext();

  const handleLevelSelect = (level: typeof userLevels[0]) => {
    setUserLevel(level);
  };

  const levelDetails = {
    beginner: {
      benefits: ['Explications simples et claires', 'Pas de jargon technique', 'Guides étape par étape'],
      color: 'green'
    },
    intermediate: {
      benefits: ['Equilibre entre simplicité et précision', 'Quelques termes techniques expliqués', 'Solutions variées'],
      color: 'blue'
    },
    advanced: {
      benefits: ['Détails techniques approfondis', 'Vocabulaire spécialisé', 'Options avancées et personnalisation'],
      color: 'purple'
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Quel est votre niveau avec la technologie ?
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Cela nous aide à adapter notre langage et nos recommandations 
            pour qu'elles vous correspondent parfaitement.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {userLevels.map((level, index) => {
            const IconComponent = (LucideIcons as any)[level.icon] || LucideIcons.User;
            const isSelected = userLevel?.id === level.id;
            const details = levelDetails[level.id as keyof typeof levelDetails];

            return (
              <motion.button
                key={level.id}
                onClick={() => handleLevelSelect(level)}
                className={`
                  p-8 rounded-2xl text-center transition-all duration-300 border-2
                  ${isSelected
                    ? `border-${details.color}-500 bg-${details.color}-50 shadow-xl shadow-${details.color}-500/20`
                    : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-lg'
                  }
                `}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.2 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className={`
                  w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6
                  ${isSelected 
                    ? `bg-${details.color}-500 text-white` 
                    : 'bg-gray-100 text-gray-600'
                  }
                `}>
                  <IconComponent className="w-10 h-10" />
                </div>
                
                <h3 className={`
                  font-bold text-2xl mb-3
                  ${isSelected ? `text-${details.color}-900` : 'text-gray-900'}
                `}>
                  {level.name}
                </h3>
                
                <p className={`
                  text-lg mb-6 leading-relaxed
                  ${isSelected ? `text-${details.color}-700` : 'text-gray-600'}
                `}>
                  {level.description}
                </p>

                {isSelected && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="border-t border-current/20 pt-6"
                  >
                    <h4 className={`font-semibold text-${details.color}-900 mb-3`}>
                      Ce que vous obtiendrez :
                    </h4>
                    <ul className="space-y-2">
                      {details.benefits.map((benefit, idx) => (
                        <li key={idx} className={`text-sm text-${details.color}-700 flex items-start`}>
                          <span className="mr-2">•</span>
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </motion.div>
                )}
              </motion.button>
            );
          })}
        </div>

        {userLevel && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-green-50 rounded-xl border border-blue-200"
          >
            <div className="flex items-center justify-center">
              <div className="text-center">
                <h4 className="font-semibold text-gray-900 mb-2">
                  Parfait ! Niveau {userLevel.name} sélectionné
                </h4>
                <p className="text-gray-700">
                  Nous allons adapter nos explications à votre niveau d'expérience.
                </p>
              </div>
            </div>
          </motion.div>
        )}

        <Navigation
          onPrevious={onPrevious}
          onNext={onNext}
          canGoBack={true}
          canProceed={canProceed}
        />
      </motion.div>
    </div>
  );
};

export default Step3Level;