export interface Category {
  id: string;
  name: string;
  description: string;
  icon: string;
  prompt: string;
  examples: string[];
}

export interface UserLevel {
  id: string;
  name: string;
  description: string;
  icon: string;
  vocabulary: 'simple' | 'intermediate' | 'advanced';
}

export interface UploadedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  content?: string;
  url?: string;
}

export interface AppState {
  currentStep: number;
  selectedCategory: Category | null;
  problemDescription: string;
  userLevel: UserLevel | null;
  uploadedFiles: UploadedFile[];
  aiResponse: string;
  isLoading: boolean;
  error: string | null;
  rating: number;
  feedback: string;
}

export interface StepProps {
  onNext: () => void;
  onPrevious: () => void;
  canProceed: boolean;
}