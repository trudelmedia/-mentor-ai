import OpenAI from 'openai';
import { Category, UserLevel, UploadedFile } from '../types';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  organization: import.meta.env.VITE_OPENAI_ORG_ID,
  dangerouslyAllowBrowser: true
});

export const analyzeUserProblem = async (
  category: Category,
  problemDescription: string,
  userLevel: UserLevel,
  uploadedFiles: UploadedFile[]
): Promise<string> => {
  const filesContext = uploadedFiles.length > 0 
    ? `\n\nFichiers joints :\n${uploadedFiles.map(f => `- ${f.name} (${f.type}): ${f.content || 'Fichier attaché'}`).join('\n')}`
    : '';

  const levelInstructions = {
    simple: 'Utilise un langage très simple, évite le jargon technique, donne des exemples concrets.',
    intermediate: 'Tu peux utiliser quelques termes techniques mais explique-les. Sois précis mais accessible.',
    advanced: 'Tu peux utiliser un vocabulaire technique, donner des détails approfondis et des références.'
  };

  const prompt = `
${category.prompt}

Niveau de l'utilisateur : ${userLevel.name} (${levelInstructions[userLevel.vocabulary]})

Contexte : ${category.name}
Problème décrit : ${problemDescription}${filesContext}

En tant qu'expert en ${category.name}, propose une réponse structurée avec :

1. **Analyse de la situation** : Résume clairement le problème identifié
2. **Solutions concrètes avec l'IA** : 2-3 solutions spécifiques utilisant des outils IA
3. **Outils recommandés** : Liste d'outils IA précis avec leurs avantages
4. **Exemple pratique** : Un exemple immédiat ou une démonstration
5. **Prochaines étapes** : Actions concrètes à entreprendre

Adapte ton langage au niveau ${userLevel.name} et reste encourageant et pratique.
Limite ta réponse à 800 mots maximum.
`;

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'Tu es un assistant IA expert qui aide les utilisateurs à découvrir comment l\'intelligence artificielle peut résoudre leurs problèmes quotidiens. Tu es bienveillant, précis et pratique.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      max_tokens: 1200,
      temperature: 0.7
    });

    return completion.choices[0]?.message?.content || 'Désolé, je n\'ai pas pu générer une réponse appropriée.';
  } catch (error) {
    console.error('OpenAI API Error:', error);
    throw new Error('Erreur lors de l\'analyse IA. Veuillez réessayer.');
  }
};

export const retryWithBackoff = async <T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  baseDelay: number = 1000
): Promise<T> => {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      if (attempt === maxRetries) throw error;
      
      const delay = baseDelay * Math.pow(2, attempt - 1);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  throw new Error('Max retries exceeded');
};