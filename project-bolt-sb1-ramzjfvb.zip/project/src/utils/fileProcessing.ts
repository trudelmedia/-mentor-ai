import { UploadedFile } from '../types';

export const processFile = async (file: File): Promise<UploadedFile> => {
  const id = Math.random().toString(36).substr(2, 9);
  
  const uploadedFile: UploadedFile = {
    id,
    name: file.name,
    type: file.type,
    size: file.size
  };

  // Process text files
  if (file.type.startsWith('text/') || file.name.endsWith('.txt')) {
    const content = await file.text();
    uploadedFile.content = content.substring(0, 2000); // Limit content length
  }
  
  // Process images
  else if (file.type.startsWith('image/')) {
    const url = URL.createObjectURL(file);
    uploadedFile.url = url;
    uploadedFile.content = `Image: ${file.name}`;
  }
  
  // Process PDFs (simplified - in real app you'd use pdf-parse)
  else if (file.type === 'application/pdf') {
    uploadedFile.content = `PDF Document: ${file.name} (${(file.size / 1024 / 1024).toFixed(1)} MB)`;
  }
  
  // Other file types
  else {
    uploadedFile.content = `Fichier: ${file.name} (${file.type})`;
  }

  return uploadedFile;
};

export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 B';
  
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
};

export const isFileTypeAllowed = (file: File): boolean => {
  const allowedTypes = [
    'text/plain',
    'text/csv',
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp'
  ];
  
  return allowedTypes.includes(file.type) || file.name.endsWith('.txt');
};

export const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
export const MAX_FILES = 5;