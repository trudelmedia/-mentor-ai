import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AppState, Category, UserLevel, UploadedFile } from '../types';

interface AppContextType extends AppState {
  setCurrentStep: (step: number) => void;
  setSelectedCategory: (category: Category | null) => void;
  setProblemDescription: (description: string) => void;
  setUserLevel: (level: UserLevel | null) => void;
  setUploadedFiles: (files: UploadedFile[]) => void;
  addUploadedFile: (file: UploadedFile) => void;
  removeUploadedFile: (fileId: string) => void;
  setAiResponse: (response: string) => void;
  setIsLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  setRating: (rating: number) => void;
  setFeedback: (feedback: string) => void;
  resetState: () => void;
  saveProgress: () => void;
  loadProgress: () => void;
}

const initialState: AppState = {
  currentStep: 1,
  selectedCategory: null,
  problemDescription: '',
  userLevel: null,
  uploadedFiles: [],
  aiResponse: '',
  isLoading: false,
  error: null,
  rating: 0,
  feedback: ''
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const [state, setState] = useState<AppState>(initialState);

  // Auto-save to localStorage
  useEffect(() => {
    const timer = setTimeout(() => {
      saveProgress();
    }, 1000);
    return () => clearTimeout(timer);
  }, [state]);

  // Load progress on mount
  useEffect(() => {
    loadProgress();
  }, []);

  const setCurrentStep = (step: number) => {
    setState(prev => ({ ...prev, currentStep: step }));
  };

  const setSelectedCategory = (category: Category | null) => {
    setState(prev => ({ ...prev, selectedCategory: category }));
  };

  const setProblemDescription = (description: string) => {
    setState(prev => ({ ...prev, problemDescription: description }));
  };

  const setUserLevel = (level: UserLevel | null) => {
    setState(prev => ({ ...prev, userLevel: level }));
  };

  const setUploadedFiles = (files: UploadedFile[]) => {
    setState(prev => ({ ...prev, uploadedFiles: files }));
  };

  const addUploadedFile = (file: UploadedFile) => {
    setState(prev => ({
      ...prev,
      uploadedFiles: [...prev.uploadedFiles, file]
    }));
  };

  const removeUploadedFile = (fileId: string) => {
    setState(prev => ({
      ...prev,
      uploadedFiles: prev.uploadedFiles.filter(f => f.id !== fileId)
    }));
  };

  const setAiResponse = (response: string) => {
    setState(prev => ({ ...prev, aiResponse: response }));
  };

  const setIsLoading = (loading: boolean) => {
    setState(prev => ({ ...prev, isLoading: loading }));
  };

  const setError = (error: string | null) => {
    setState(prev => ({ ...prev, error }));
  };

  const setRating = (rating: number) => {
    setState(prev => ({ ...prev, rating }));
  };

  const setFeedback = (feedback: string) => {
    setState(prev => ({ ...prev, feedback }));
  };

  const resetState = () => {
    setState(initialState);
    localStorage.removeItem('ia-starter-progress');
  };

  const saveProgress = () => {
    try {
      localStorage.setItem('ia-starter-progress', JSON.stringify(state));
    } catch (error) {
      console.warn('Failed to save progress:', error);
    }
  };

  const loadProgress = () => {
    try {
      const saved = localStorage.getItem('ia-starter-progress');
      if (saved) {
        const parsedState = JSON.parse(saved);
        setState(prev => ({ ...prev, ...parsedState, isLoading: false, error: null }));
      }
    } catch (error) {
      console.warn('Failed to load progress:', error);
    }
  };

  const contextValue: AppContextType = {
    ...state,
    setCurrentStep,
    setSelectedCategory,
    setProblemDescription,
    setUserLevel,
    setUploadedFiles,
    addUploadedFile,
    removeUploadedFile,
    setAiResponse,
    setIsLoading,
    setError,
    setRating,
    setFeedback,
    resetState,
    saveProgress,
    loadProgress
  };

  return (
    <AppContext.Provider value={contextValue}>
      {children}
    </AppContext.Provider>
  );
};