import React from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface NavigationProps {
  onPrevious: () => void;
  onNext: () => void;
  canGoBack: boolean;
  canProceed: boolean;
  isLoading?: boolean;
  nextLabel?: string;
}

const Navigation: React.FC<NavigationProps> = ({
  onPrevious,
  onNext,
  canGoBack,
  canProceed,
  isLoading = false,
  nextLabel = 'Continuer'
}) => {
  return (
    <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-200">
      <motion.button
        onClick={onPrevious}
        disabled={!canGoBack}
        className={`
          flex items-center px-6 py-3 rounded-lg font-medium transition-all
          ${canGoBack 
            ? 'text-gray-600 hover:text-gray-800 hover:bg-gray-100' 
            : 'text-gray-400 cursor-not-allowed'
          }
        `}
        whileHover={canGoBack ? { scale: 1.02 } : {}}
        whileTap={canGoBack ? { scale: 0.98 } : {}}
      >
        <ChevronLeft className="w-5 h-5 mr-2" />
        Précédent
      </motion.button>

      <motion.button
        onClick={onNext}
        disabled={!canProceed || isLoading}
        className={`
          flex items-center px-8 py-3 rounded-lg font-semibold transition-all
          ${canProceed && !isLoading
            ? 'bg-blue-500 text-white hover:bg-blue-600 shadow-lg hover:shadow-xl' 
            : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }
        `}
        whileHover={canProceed && !isLoading ? { scale: 1.02 } : {}}
        whileTap={canProceed && !isLoading ? { scale: 0.98 } : {}}
      >
        {isLoading ? (
          <>
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2" />
            Analyse en cours...
          </>
        ) : (
          <>
            {nextLabel}
            <ChevronRight className="w-5 h-5 ml-2" />
          </>
        )}
      </motion.button>
    </div>
  );
};

export default Navigation;