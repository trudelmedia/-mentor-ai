// src/components/IntroHero.tsx
import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

type IntroHeroProps = {
  onComplete: () => void;
};

export default function IntroHero({ onComplete }: IntroHeroProps) {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
      onComplete();
    }, 4000);
    return () => clearTimeout(timer);
  }, [onComplete]);

  const handleClick = () => {
    setVisible(false);
    onComplete();
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black text-white"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {/* Background animé réseau neuronal */}
          <div className="absolute inset-0 overflow-hidden">
            <svg className="w-full h-full" viewBox="0 0 800 600">
              <defs>
                <radialGradient id="grad" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#4f46e5" stopOpacity="1" />
                  <stop offset="100%" stopColor="#0f172a" stopOpacity="0.3" />
                </radialGradient>
              </defs>
              <rect width="800" height="600" fill="url(#grad)" />
              {[...Array(20)].map((_, i) => (
                <circle
                  key={i}
                  cx={Math.random() * 800}
                  cy={Math.random() * 600}
                  r="3"
                  fill="#ffffffaa"
                />
              ))}
              {/* Nom de l’app au centre */}
              <text
                x="400"
                y="300"
                textAnchor="middle"
                fill="white"
                fontSize="32"
                fontWeight="bold"
              >
                IA Starter
              </text>
            </svg>
          </div>

          {/* Slogan & CTA */}
          <div className="relative z-10 text-center px-6">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              Perdu dans le monde de l’IA ? Reprenez le contrôle en 5 étapes.
            </h1>
            <button
              onClick={handleClick}
              className="mt-4 px-6 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 transition"
            >
              Commençons
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
