import React from 'react';
import { motion } from 'framer-motion';
import { Brain, Github, Twitter, Mail } from 'lucide-react';
import ProgressBar from './ProgressBar';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <motion.div
              className="flex items-center space-x-3"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">IA Starter</h1>
                <p className="text-sm text-gray-600">Découvrez l'IA qui vous aide</p>
              </div>
            </motion.div>

            <div className="hidden md:flex items-center space-x-4">
              <span className="text-sm text-gray-600">
                Et si l'IA pouvait vraiment vous aider... aujourd'hui ?
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Progress Bar */}
      <ProgressBar />

      {/* Main Content */}
      <main className="min-h-screen pb-20">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-4xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <Brain className="w-5 h-5 text-white" />
                </div>
                <span className="text-lg font-semibold">IA Starter</span>
              </div>
              <p className="text-gray-400 leading-relaxed">
                Découvrez comment l'intelligence artificielle peut transformer 
                votre quotidien en 5 étapes simples.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Ressources</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Guide d'utilisation</a></li>
                <li><a href="#" className="hover:text-white transition-colors">FAQ</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog IA</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Outils recommandés</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Mail className="w-5 h-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Twitter className="w-5 h-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Github className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 IA Starter. Fait avec ❤️ pour démocratiser l'IA.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;