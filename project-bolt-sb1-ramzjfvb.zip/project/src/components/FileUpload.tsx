import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, X, File, Image, FileText } from 'lucide-react';
import { useAppContext } from '../contexts/AppContext';
import { processFile, formatFileSize, isFileTypeAllowed, MAX_FILE_SIZE, MAX_FILES } from '../utils/fileProcessing';
import toast from 'react-hot-toast';

const FileUpload: React.FC = () => {
  const { uploadedFiles, addUploadedFile, removeUploadedFile } = useAppContext();

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    for (const file of acceptedFiles) {
      if (uploadedFiles.length >= MAX_FILES) {
        toast.error(`Maximum ${MAX_FILES} fichiers autorisés`);
        break;
      }

      if (file.size > MAX_FILE_SIZE) {
        toast.error(`Le fichier ${file.name} est trop volumineux (max 10MB)`);
        continue;
      }

      if (!isFileTypeAllowed(file)) {
        toast.error(`Type de fichier non supporté: ${file.name}`);
        continue;
      }

      try {
        const processedFile = await processFile(file);
        addUploadedFile(processedFile);
        toast.success(`Fichier ajouté: ${file.name}`);
      } catch (error) {
        toast.error(`Erreur lors du traitement: ${file.name}`);
      }
    }
  }, [uploadedFiles.length, addUploadedFile]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/*': ['.txt', '.csv'],
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'image/*': ['.jpeg', '.jpg', '.png', '.gif', '.webp']
    },
    maxFiles: MAX_FILES,
    maxSize: MAX_FILE_SIZE
  });

  const getFileIcon = (type: string) => {
    if (type.startsWith('image/')) return Image;
    if (type === 'application/pdf') return FileText;
    return File;
  };

  return (
    <div className="space-y-4">
      <motion.div
        {...getRootProps()}
        className={`
          border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors
          ${isDragActive 
            ? 'border-blue-400 bg-blue-50' 
            : 'border-gray-300 hover:border-gray-400'
          }
        `}
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.99 }}
      >
        <input {...getInputProps()} />
        <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        {isDragActive ? (
          <p className="text-blue-600 font-medium">Déposez vos fichiers ici...</p>
        ) : (
          <div>
            <p className="text-gray-600 font-medium mb-2">
              Glissez-déposez vos fichiers ici, ou cliquez pour sélectionner
            </p>
            <p className="text-sm text-gray-500">
              PDF, Word, images, texte • Max {formatFileSize(MAX_FILE_SIZE)} par fichier
            </p>
          </div>
        )}
      </motion.div>

      <AnimatePresence>
        {uploadedFiles.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="space-y-2"
          >
            <h4 className="font-medium text-gray-900">Fichiers ajoutés:</h4>
            {uploadedFiles.map((file) => {
              const IconComponent = getFileIcon(file.type);
              return (
                <motion.div
                  key={file.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                >
                  <div className="flex items-center space-x-3">
                    <IconComponent className="w-5 h-5 text-gray-500" />
                    <div>
                      <p className="font-medium text-gray-900">{file.name}</p>
                      <p className="text-sm text-gray-500">{formatFileSize(file.size)}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => removeUploadedFile(file.id)}
                    className="p-1 text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </motion.div>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default FileUpload;