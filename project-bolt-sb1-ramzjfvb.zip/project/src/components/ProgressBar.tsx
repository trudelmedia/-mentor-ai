import React from 'react';
import { motion } from 'framer-motion';
import { useAppContext } from '../contexts/AppContext';
import { Check } from 'lucide-react';

const ProgressBar: React.FC = () => {
  const { currentStep } = useAppContext();
  const totalSteps = 5;

  const steps = [
    { number: 1, title: 'Catégorie' },
    { number: 2, title: 'Description' },
    { number: 3, title: 'Niveau' },
    { number: 4, title: 'Analyse' },
    { number: 5, title: 'Résultat' }
  ];

  return (
    <div className="w-full bg-white shadow-sm border-b border-gray-100">
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          {steps.map((step, index) => (
            <div key={step.number} className="flex items-center">
              <div className="flex flex-col items-center">
                <motion.div
                  className={`
                    w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold
                    ${currentStep > step.number 
                      ? 'bg-green-500 text-white' 
                      : currentStep === step.number
                        ? 'bg-blue-500 text-white'
                        : 'bg-gray-200 text-gray-500'
                    }
                  `}
                  initial={{ scale: 0.8 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.2 }}
                >
                  {currentStep > step.number ? (
                    <Check className="w-5 h-5" />
                  ) : (
                    step.number
                  )}
                </motion.div>
                <span className={`
                  mt-2 text-xs font-medium
                  ${currentStep >= step.number ? 'text-gray-900' : 'text-gray-500'}
                `}>
                  {step.title}
                </span>
              </div>
              
              {index < steps.length - 1 && (
                <div className="hidden sm:block w-12 lg:w-24 mx-2 mt-[-20px]">
                  <div className={`
                    h-1 rounded-full transition-colors duration-300
                    ${currentStep > step.number ? 'bg-green-500' : 'bg-gray-200'}
                  `} />
                </div>
              )}
            </div>
          ))}
        </div>
        
        <div className="mt-4">
          <div className="bg-gray-200 rounded-full h-2">
            <motion.div
              className="bg-blue-500 h-2 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${(currentStep / totalSteps) * 100}%` }}
              transition={{ duration: 0.5, ease: 'easeInOut' }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgressBar;