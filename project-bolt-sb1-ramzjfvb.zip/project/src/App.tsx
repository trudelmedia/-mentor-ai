import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Layout from './components/Layout';
import { AppProvider } from './contexts/AppContext';
import Step1Category from './steps/Step1Category';
import Step2Description from './steps/Step2Description';
import Step3Level from './steps/Step3Level';
import Step4Analysis from './steps/Step4Analysis';
import Step5Results from './steps/Step5Results';
import { Toaster } from 'react-hot-toast';

function IntroHero({ onComplete }: { onComplete: () => void }) {
  const [showSlogan, setShowSlogan] = useState(false);
  const [showTitle, setShowTitle] = useState(false);

  useEffect(() => {
    const timers = [
      setTimeout(() => setShowSlogan(true), 0),
      setTimeout(() => setShowTitle(true), 3000),
      setTimeout(() => onComplete(), 5500),
    ];

    return () => timers.forEach(clearTimeout);
  }, []);

  const particles = Array.from({ length: 130 }).map((_, i) => ({
    id: i,
    size: Math.random() * 4 + 1,
    top: `${Math.random() * 100}%`,
    left: `${Math.random() * 100}%`,
    animationDuration: `${Math.random() * 4 + 3}s`,
    opacity: Math.random() * 0.5 + 0.5,
  }));

  return (
    <div className="relative flex h-screen items-center justify-center overflow-hidden bg-gradient-to-br from-[#080029] via-[#18006b] to-[#24235c] text-white">
      <div className="absolute inset-0">
        {particles.map(p => (
          <div
            key={p.id}
            className="absolute rounded-full bg-white"
            style={{
              width: p.size,
              height: p.size,
              top: p.top,
              left: p.left,
              opacity: p.opacity,
              animation: `floatUp ${p.animationDuration} ease-in-out infinite`,
            }}
          />
        ))}
      </div>

      <AnimatePresence>
        {showSlogan && (
          <motion.div
            key="slogan"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1 }}
            className="z-10 text-center text-xl md:text-2xl"
          >
            <p>Perdu dans le monde de l'IA ? Reprenez le contrôle en 5 étapes.</p>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showTitle && (
          <motion.div
            key="title"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1 }}
            className="absolute top-[55%] text-center text-4xl font-bold text-white drop-shadow-lg"
          >
            IA Starter
          </motion.div>
        )}
      </AnimatePresence>

      <style jsx>{`
        @keyframes floatUp {
          0% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-30px);
          }
          100% {
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}

export default function App() {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [problemDescription, setProblemDescription] = useState('');
  const [userLevel, setUserLevel] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [showIntro, setShowIntro] = useState(true);

  const handleContext = () => setCurrentStep(currentStep + 1);
  const handlePrevious = () => setCurrentStep(currentStep - 1);

  const canProceedToStep = (step: number): boolean => {
    switch (step) {
      case 1:
        return !!selectedCategory;
      case 2:
        return problemDescription.length > 30;
      case 3:
        return !!userLevel;
      case 4:
        return !!aiResponse;
      default:
        return false;
    }
  };

  const renderCurrentStep = () => {
    const commonProps = {
      context: handleContext,
      onPrevious: handlePrevious,
      canProceed: canProceedToStep(currentStep),
    };

    switch (currentStep) {
      case 1:
        return <Step1Category {...commonProps} />;
      case 2:
        return <Step2Description {...commonProps} />;
      case 3:
        return <Step3Level {...commonProps} />;
      case 4:
        return <Step4Analysis {...commonProps} />;
      case 5:
        return <Step5Results {...commonProps} />;
      default:
        return <Step1Category {...commonProps} />;
    }
  };

  return (
    <AppProvider>
      {showIntro ? (
        <IntroHero onComplete={() => setShowIntro(false)} />
      ) : (
        <>
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: '#fff',
                border: '1px solid #3c3cdb',
                borderRadius: '12px',
                boxShadow: '0 10px 20px -5px rgba(0,0,0,0.1)',
              },
              success: {
                iconTheme: {
                  primary: '#10b981',
                  secondary: '#fff',
                },
              },
              error: {
                iconTheme: {
                  primary: '#ef4444',
                  secondary: '#fff',
                },
              },
            }}
          />
          <Layout>{renderCurrentStep()}</Layout>
        </>
      )}
    </AppProvider>
  );
}