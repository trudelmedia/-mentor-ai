# IA Starter - Découvrez l'IA qui vous aide

Une application web moderne qui guide les utilisateurs à travers 5 étapes simples pour découvrir comment l'intelligence artificielle peut les aider concrètement dans leur quotidien.

## 🚀 Fonctionnalités

- **Parcours guidé en 5 étapes** avec navigation fluide et indicateur de progression
- **Intégration OpenAI GPT-4** avec profils personnalisés par catégorie
- **Upload de fichiers** avec prévisualisation (images, PDF, documents)
- **Interface responsive** mobile-first avec animations et micro-interactions
- **Gestion d'état avancée** avec Context API et sauvegarde localStorage
- **Export PDF** des recommandations et partage par email
- **Système de rating** et feedback utilisateur
- **Gestion d'erreurs robuste** avec retry automatique

## 🎨 Design

- Palette moderne : primaire #3B82F6, secondaire #10B981, accent #F59E0B
- Typographie Inter avec hiérarchie claire et contraste WCAG AA
- Design system cohérent avec espacement 8px
- Animations subtiles avec Framer Motion
- Interface lumineuse et rassurante avec icônes Lucide React

## 🛠️ Technologies

- **React 18** + TypeScript
- **Vite** pour le bundling et dev server
- **Tailwind CSS** pour le styling
- **Framer Motion** pour les animations
- **OpenAI API** pour l'analyse IA
- **React Dropzone** pour l'upload de fichiers
- **React Hot Toast** pour les notifications

## 📦 Installation

1. Clonez le repository :
```bash
git clone <repository-url>
cd ia-starter
```

2. Installez les dépendances :
```bash
npm install
```

3. Configurez les variables d'environnement :
```bash
cp .env.example .env
```

4. Ajoutez vos clés OpenAI dans le fichier `.env` :
```env
VITE_OPENAI_API_KEY=your_openai_api_key_here
VITE_OPENAI_ORG_ID=your_openai_org_id_here
```

5. Démarrez le serveur de développement :
```bash
npm run dev
```

## 🌐 Déploiement

### Netlify (recommandé)

1. Connectez votre repository à Netlify
2. Configurez les variables d'environnement dans Netlify :
   - `VITE_OPENAI_API_KEY`
   - `VITE_OPENAI_ORG_ID`
3. Déployez automatiquement à chaque push

### Vercel

1. Installez Vercel CLI : `npm i -g vercel`
2. Déployez : `vercel`
3. Configurez les variables d'environnement dans le dashboard Vercel

## 📱 Utilisation

### Étape 1 : Choisir une catégorie
- 10 catégories disponibles : Éducation, Famille, Travail, etc.
- Chaque catégorie a un profil LLM spécialisé
- Interface en grille responsive avec hover effects

### Étape 2 : Décrire le problème
- Zone de texte avec exemples rotatifs
- Upload de fichiers multiples (max 10MB, 5 fichiers)
- Support : PDF, images, documents texte
- Minimum 50 caractères requis

### Étape 3 : Niveau technologique
- 3 niveaux : Débutant, Intermédiaire, Avancé
- Adapte le vocabulaire et la complexité des réponses
- Interface en cartes avec personas visuels

### Étape 4 : Analyse IA
- Animation en temps réel du processus d'analyse
- Appel API OpenAI avec retry automatique
- Gestion d'erreurs avec possibilité de réessayer

### Étape 5 : Résultats
- Recommandations personnalisées formatées
- Export PDF et partage par email
- Système de rating 5 étoiles
- Possibilité de recommencer

## 🔧 Configuration API OpenAI

L'application utilise GPT-4 avec des prompts personnalisés par catégorie :

```typescript
const prompt = `
${category.prompt}
Niveau de l'utilisateur : ${userLevel.name}
Contexte : ${category.name}
Problème décrit : ${problemDescription}

En tant qu'expert en ${category.name}, propose :
1. Une analyse claire du problème
2. 2-3 solutions concrètes avec l'IA
3. Des outils spécifiques à tester
4. Un exemple immédiat
5. Les prochaines étapes recommandées
`;
```

## 📊 Structure du projet

```
src/
├── components/          # Composants réutilisables
│   ├── Layout.tsx      # Layout principal avec header/footer
│   ├── ProgressBar.tsx # Barre de progression
│   ├── Navigation.tsx  # Navigation entre étapes
│   └── FileUpload.tsx  # Upload de fichiers
├── contexts/           # Gestion d'état
│   └── AppContext.tsx  # Context principal
├── data/              # Données statiques
│   ├── categories.ts  # Définition des catégories
│   └── userLevels.ts  # Niveaux utilisateur
├── steps/             # Composants d'étapes
│   ├── Step1Category.tsx
│   ├── Step2Description.tsx
│   ├── Step3Level.tsx
│   ├── Step4Analysis.tsx
│   └── Step5Results.tsx
├── types/             # Types TypeScript
│   └── index.ts
├── utils/             # Utilitaires
│   ├── openai.ts      # Intégration OpenAI
│   └── fileProcessing.ts # Traitement fichiers
└── App.tsx            # Composant principal
```

## 🔒 Sécurité

- Variables d'environnement pour les clés API
- Validation côté client des fichiers uploadés
- Limitation de taille et types de fichiers
- Rate limiting intégré dans l'API OpenAI
- Gestion d'erreurs robuste

## 🎯 Roadmap

- [ ] Authentification utilisateur optionnelle
- [ ] Historique des consultations
- [ ] Partage sur réseaux sociaux
- [ ] Mode sombre/clair
- [ ] Support multilingue
- [ ] Analytics avancées
- [ ] API backend dédiée
- [ ] PWA (Progressive Web App)

## 🤝 Contribution

1. Fork le projet
2. Créez une branche feature (`git checkout -b feature/AmazingFeature`)
3. Committez vos changements (`git commit -m 'Add some AmazingFeature'`)
4. Push sur la branche (`git push origin feature/AmazingFeature`)
5. Ouvrez une Pull Request

## 📄 Licence

Ce projet est sous licence MIT. Voir le fichier `LICENSE` pour plus de détails.

## 🙏 Remerciements

- [OpenAI](https://openai.com) pour l'API GPT-4
- [Lucide](https://lucide.dev) pour les icônes
- [Tailwind CSS](https://tailwindcss.com) pour le styling
- [Framer Motion](https://framer.com/motion) pour les animations

---

Fait avec ❤️ pour démocratiser l'IA et la rendre accessible à tous.